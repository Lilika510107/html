package com.example.myapplication

import android.widget.RadioButton

//package com.example.countdowndemo

import android.app.Dialog
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast



import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.myapplication.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
//import com.example.countdowndemo.R.string.remain
//import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    //這是要讓倒數計時器可以倒數的變數
    //private lateinit var timer: CountDownTimer
    //private var timerLengthSeconds: Long= 0L
    //private var timerState= TimerState.Stopped
    //private var secondRemaining =0L

    //倒數計時器控制開始倒數、停止(失敗)
    //var fab_start = findViewById<Button>(R.id.button_first)
    //var fab_stop = findViewById<Button>(R.id.button_second)

    //控制讓動畫可以跑
    //val button_first = findViewById<Button>(R.id.button_first)
    //val progressBar = findViewById<ProgressBar>(R.id.progress_countdown)
    //val button_second = findViewById<Button>(R.id.button_second)




    private var timeSelected : Int = 0
    private var timeCountDown: CountDownTimer? = null
    private var timeProgress = 0
    private var pauseOffSet: Long = 0
    private var isStart = true







    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }

        //super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        //object : CountDownTimer(30000, 1000) {

        //    override fun onFinish() {
        //        info.text = getString(R.string.done)
        //    }

        //    override fun onTick(millisUntilFinished: Long) {
        //        info.text = getString(remain).plus("${millisUntilFinished/1000}")
        //    }
        //}.start()

        //本來這邊要寫判斷主畫面選擇的是30分鐘還是一小時要讓倒數計時畫面可以跟著改

        var count = findViewById<TextView>(R.id.textView_countdown)
        var value1: String = "00:00"
        val radioGroup = findViewById<RadioGroup>(R.id.choose)
        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            val selectedRadioButton = findViewById<RadioButton>(checkedId)
            val selectedText = selectedRadioButton.text.toString()
            val timechoose1 = findViewById<RadioButton>(R.id.radioButton)
            timechoose1.setOnCheckedChangeListener { radiobuttonView, isChecked ->
                if (isChecked) {
                    value1 = "30:00"
                } else {
                    value1 = "60:00"
                }
                val fragment = SecondFragment() // 替換 YourFragment 為你的 Fragment 類名稱
                val bundle = Bundle()
                bundle.putString("key", "value1")
                fragment.arguments = bundle

                supportFragmentManager.beginTransaction()
                    .replace(R.id.textView_countdown, fragment)
                    .commit()
            }

            Toast.makeText(this, "選擇的是：$selectedText", Toast.LENGTH_SHORT).show()
        }




        //判斷開始倒數了沒
        //fab_start.setOnClickListener{
            //startTimer()
            //omTimerFinished()
        //}
        //fab_stop.setOnClickListener{
            //timer.cancel()
            //onTimerFinished()
        //}
    }

    //本來是要拿來跑開始倒數計時
    //override fun onResume() {
    //    super.onResume()
//
    //    initTimer()
    //}

    //本來是要拿來跑倒數計時停止
    //override fun onStop() {
    //    super.onResume()
//
    //    initTimer()
    //}

    //宣告一個布林值用來判斷需不需要增加層數
    //val isTrue: Boolean = true
    //宣告變數amount(樓層數)是整數
    //var amount=0
    //amount=get原本的數字
    //if 成功倒數
    //amount=amount+1
    //將新的amount push上去

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_show -> {
                startActivity(Intent(this,show::class.java))
                true
            }
            R.id.action_log -> true
            else -> super.onOptionsItemSelected(item)
        }
    }






    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }


}