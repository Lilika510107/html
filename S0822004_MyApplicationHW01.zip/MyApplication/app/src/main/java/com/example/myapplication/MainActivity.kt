package com.example.myapplication

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener{
            val value01 =findViewById<EditText>(R.id.editTextText)
            val value02 =findViewById<EditText>(R.id.editTextText2)
            val value1=value01.text.toString()
            val value2=value02.text.toString()

            val bundle=Bundle()
            bundle.putString("Key1",value1)
            bundle.putString("Key2",value2)


            //startActivity(Intent(this,MainActivity2::class.java))
            val intent = Intent(this,MainActivity2::class.java)
            intent.putExtras(bundle)
            startActivityForResult(intent,1)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int,data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        data?.extras?.let {
            if (requestCode == 1 && resultCode == RESULT_OK) {
                findViewById<TextView>(R.id.textView2).text=
                    "姓名：${it.getString("Key1")}\n\n" +
                            "性別：${it.getString("Key2")}\n\n" +
                            "尺寸：${it.getString("Key3")}\n\n" +
                            "顏色：${it.getString("Key4")}\n\n"
            }
        }
    }
}