package com.example.homework02

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val client = OkHttpClient()
        //[GET]PM2.5URL
        val url = "https://data.epa.gov.tw/api/v2/aqx_p_02?api_key=1ef05b60-74cd-4c31-87d7-67f94237d2c8"
        val request = Request.Builder()
            .url(url)
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    println(responseBody)

                    val gson = Gson()
                    val jsonObject = gson.fromJson(responseBody, JsonObject::class.java)

                    val site = jsonObject
                        .getAsJsonArray("records")[0]
                        .asJsonObject
                        .get("site")
                        .asString
                    println("站名---------${site}")

                    val county = jsonObject
                        .getAsJsonArray("records")[0]
                        .asJsonObject
                        .get("county")
                        .asString
                    println("縣名---------${county}")

                    val pm = jsonObject
                        .getAsJsonArray("records")[0]
                        .asJsonObject
                        .get("pm25")
                        .asString
                    println("濃度---------${pm}")

                    val datacreationdate = jsonObject
                        .getAsJsonArray("records")[0]
                        .asJsonObject
                        .get("datacreationdate")
                        .asString
                    println("日期---------${datacreationdate}")

                    val itemunit = jsonObject
                        .getAsJsonArray("records")[0]
                        .asJsonObject
                        .get("itemunit")
                        .asString
                    println("單位---------${itemunit}")

                    //取得回應回來內容
                    runOnUiThread {
                        //直接將內容回傳給id名稱為TextView
                        findViewById<TextView>(R.id.textView11).text = site.toString()
                        findViewById<TextView>(R.id.textView).text = county.toString()
                        findViewById<TextView>(R.id.textView2).text = pm.toString()
                        findViewById<TextView>(R.id.textView3).text = datacreationdate.toString()
                        findViewById<TextView>(R.id.textView4).text = itemunit.toString()

                    }
                } else {
                    println("Request failed")
                    runOnUiThread {
                        //直接將內容回傳給id名稱為TextView
                        findViewById<TextView>(R.id.textView11).text = "資料錯誤"
                    }

                }
            }
        })
    }
}

